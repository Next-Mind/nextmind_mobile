package com.example.nextmind_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
